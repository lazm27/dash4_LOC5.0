import 'package:flutter/material.dart';
import 'package:snappyshots/main.dart';
class Option extends StatefulWidget {
  const Option({Key? key}) : super(key: key);

  @override
  State<Option> createState() => _OptionState();
}

class _OptionState extends State<Option> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
      ),
      body: Column(
        children: [
          Text("Employer or student"),
          Row(
            children: [
              ElevatedButton(onPressed: (){}, child:
              Text('Student')),

            ],
          )

        ],
      ),
    );
  }
}
